<div class="venue_title"><h1><?php print $venue_name; ?></h1></div>
<div id="page" >
<?php include("header1.php"); ?>
<div id="tv" class="clearfix <?php print $classes; ?>">
 <?php /* if ($breadcrumb): ?>
      <div id="breadcrumb"><?php print $breadcrumb; ?></div>
    <?php endif; */ ?>
          <a id="main-content"></a>
        <?php print render($title_prefix); ?>

        <?php print render($title_suffix); ?>

        



 <?php print render($page['help']); ?>

      <?php if ($action_links): ?>

        <ul class="action-links">

          <?php print render($action_links); ?>

        </ul>

      <?php endif; ?>



      <?php if ($page['highlighted']): ?>

        <ul class="highlighted">

          <?php print render($page['highlighted']); ?>

        </ul>

      <?php endif; ?>



<?php if ($tabs): ?><div id="tabs"><?php print render($tabs); ?></div><?php endif; ?>

  

<div class="main_content">

<?php if ($title): ?><h2 class="block-title" id="page-title"><?php print $title; ?></h2><?php endif; ?>

<?php  if($is_front):
		$i = strtotime(Date("l F d, Y"));
		echo  '<h2 class="block-title">' . format_date($i, "custom", "l F d, Y")  . ' </h2>';
		endif;
?>



<?php print render($page['content']); ?>

<?php print $feed_icons; ?>



</div>

<?php // if(!isset($node)): ?>

<div class="sidebar">
<?php if($page['search_box']): ?>

<div class="search-wrapper"><?php print render($page['search_box']); ?></div>

<?php endif; ?>
</div>

<?php // endif; ?>



</div>

<?php if($page['footer']): ?>

<div id="footer" class="inner_container">

<div id="footer-wrapper" class="clearfix"> <?php print render($page['footer']); ?> </div><div>

<?php endif; ?>

</div>

<?php if($page['page_bottom']): ?>

<div id="page-bottom-wrapper">

<?php print render($page['page_bottom']); ?>

</div>

<?php endif; ?>
</div>