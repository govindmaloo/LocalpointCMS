<?php
/**
 * @file views-view-unformatted.tpl.php
 * Default simple view template to display a list of rows.
 *
 * @ingroup views_templates
 */
 if(!isset($_SESSION['ad_banner'])){
	$_SESSION['ad_banner'] = TRUE;
 }

?>


<?php if (!empty($title)): ?>
  <h3><?php print $title; ?></h3>
<?php endif; ?>

<?php $i = 1; foreach ($rows as $id => $row): ?>
  <div class="<?php print $classes_array[$id]; ?>">
    <?php 
			print $row; ?>
			<div class="block-wrapper">
				<?php	if($i==theme_get_setting('ad_banner_position') && ($_SESSION['ad_banner'] == TRUE)){
							$_SESSION['ad_banner'] = FALSE;
							$block = module_invoke('views', 'block_view', 'ad_banner_left-block');
							//print_r($block);
							print render($block);
							
							}
							$i++; 
			?>
				
                </div>
  </div>
<?php endforeach; ?>
<?php unset($_SESSION['ad_banner']); ?>