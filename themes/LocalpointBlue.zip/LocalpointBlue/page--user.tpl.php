<div id="page">
<div id="header-wrapper" class="clearfix">

<div id="header">

<div id="logo" class="clearfix">

    <?php if ($logo): ?>

      <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home" >

        <img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />

      </a>

    <?php endif; ?>

			</div>

<?php /* Menu commented

<div class="social_menu">

<?php if($page['social_menu']): 

		print render($page['social_menu']);

 endif ?>

</div>

<div id="menu-with-search" class="clearfix">

<?php if($page['main_menu_links']): ?>

<div id="main_menu_wrapper" >

<?php print render($page['main_menu_links']);?>



</div>

<?php endif; ?>



<?php if($page['search_box']): ?>

<div class="search-wrapper"><?php print render($page['search_box']); ?></div>

<?php endif; ?>

</div>

*/ ?>

<?php if($page['header']): ?>

<div id="header-block" class="inner_container"> <?php print render($page['header']); ?> </div>

<?php endif; ?>

</div>

<?php 

//global $user;

// Grab the user roles

//$roles = $user->roles;



//if ($messages && (in_array('administrator', array_values($user->roles)))): ?>

   <div id="messages"><div class="section clearfix">

      <?php print $messages; ?>

    </div></div> <!-- /.section, /#messages -->

  <?php //endif;  ?>

  

  



</div>

<div id="user-page" class="clearfix <?php print $classes; ?>">



<?php print render($page['help']); ?>

 <?php if ($breadcrumb): ?>

      <div id="breadcrumb"><?php print $breadcrumb; ?></div>

    <?php endif; ?>

<div class="main_content">

<div class="inner_container">

        <a id="main-content"></a>

        <?php print render($title_prefix); ?>

        <?php if ($title): ?><h1 class="title" id="page-title"><?php print $title; ?></h1><?php endif; ?>

        <?php print render($title_suffix); ?>

        <?php if ($tabs): ?><div id="tabs"><?php print render($tabs); ?></div><?php endif; ?>

         <?php print render($page['help']); ?>

      <?php if ($action_links): ?>

        <ul class="action-links">

          <?php print render($action_links); ?>

        </ul>

      <?php endif; ?>

<?php print render($page['content']); ?></div>

</div>



</div>

</div>