<div id="header-wrapper" class="clearfix">
<div id="header" class="tv">


<div class="clearfix">                    
                <?php /* if ($venue_logo): ?>
      <a href="<?php print $front_page . $tv_path; ?>" title="<?php print t('Home'); ?>" rel="home" >
        <img src="<?php print $tv_logo; ?>" alt="<?php print t('Home'); ?>" />
      </a>
    <?php endif; */?>
            
            </div>
            
     
            
</div>
<?php 
//global $user;
// Grab the user roles
//$roles = $user->roles;
//if ($messages && (in_array('administrator', array_values($user->roles)))): ?>
 <!-- /.section, /#messages -->
    <div id="messages"><div class="section clearfix">

      <?php print $messages; ?>

    </div></div>
  <?php //endif;  ?>
</div>