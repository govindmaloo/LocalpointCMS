<?php /*?><?php if($page['page_top']): ?>
<div id="page-top-wrapper">
<?php print render($page['page_top']); ?>
</div>
<?php endif; ?>

<?php include("header.php");  ?><?php */?>
<div id="content_all" class="album clearfix <?php print $classes; ?>">
  <?php /*?> <?php if ($title): ?><h2 class="block-title" id="page-title"><?php print $title; ?></h2><?php endif; ?>
        <a id="main-content"></a>
        <?php print render($title_prefix); ?>
        
        <?php print render($title_suffix); ?>
        

 <?php print render($page['help']); ?>
      <?php if ($action_links): ?>
        <ul class="action-links">
          <?php print render($action_links); ?>
        </ul>
      <?php endif; ?>

<?php if ($tabs): ?><div id="tabs"><?php print render($tabs); ?></div><?php endif; ?>
  <?php */?>

<div id="comment-page" class="clearfix <?php print $classes; ?>">
<div class="main_content">
<div class="inner_container"><?php print render($page['content']); ?></div>
</div>

</div>