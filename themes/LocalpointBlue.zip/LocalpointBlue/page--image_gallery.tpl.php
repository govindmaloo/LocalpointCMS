<?php if($page['page_top']): ?>

<div id="page-top-wrapper">

<?php print render($page['page_top']); ?>

</div>

<?php endif; ?>
<div id="page">


<?php include("header.php"); ?>



<div id="content_all" class="clearfix <?php print $classes; ?>">

 <?php if ($breadcrumb): ?>

      <div id="breadcrumb"><?php print $breadcrumb; ?></div>

    <?php endif; ?>

    

        <a id="main-content"></a>

        <?php print render($title_prefix); ?>

        

        <?php print render($title_suffix); ?>

        



 <?php print render($page['help']); ?>

      <?php if ($action_links): ?>

        <ul class="action-links">

          <?php print render($action_links); ?>

        </ul>

      <?php endif; ?>



<?php if ($tabs): ?><div id="tabs"><?php print render($tabs); ?></div><?php endif; ?>

  



<div id="comment-page" class="clearfix <?php print $classes; ?>">

<div class="main_content">

<div class="inner_container"><?php print render($page['content']); ?></div>

</div>



</div>
</div>